# AI-that-cares
Conversational AI for Emotional Support and Wellness
website link -https://aithatcares.netlify.app/
link for demo -https://youtu.be/PlwjGorY8lo![image](https://github.com/user-attachments/assets/67626a64-ccfc-429a-adc7-45904b6844d6)
